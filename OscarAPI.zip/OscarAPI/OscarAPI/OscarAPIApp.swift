//
//  OscarAPIApp.swift
//  OscarAPI
//
//  Created by Andre Gerez Foratto on 25/05/24.
//

import SwiftUI

@main
struct OscarAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
